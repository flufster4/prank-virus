This is a prank viruse!
to run it double click the file that is called "runner.bat"